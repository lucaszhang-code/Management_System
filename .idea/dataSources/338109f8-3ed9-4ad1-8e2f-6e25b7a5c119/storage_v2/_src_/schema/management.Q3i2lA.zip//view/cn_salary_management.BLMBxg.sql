create definer = root@localhost view cn_salary_management as
select `management`.`salary_management`.`sal_id`      AS `工资编号`,
       `management`.`salary_management`.`sal_name`    AS `员工姓名`,
       `management`.`salary_management`.`sal_base`    AS `基础工资`,
       `management`.`salary_management`.`sal_reward`  AS `绩效奖金`,
       `management`.`salary_management`.`sal_subsidy` AS `补贴`,
       `management`.`salary_management`.`sal_sum`     AS `工资总额`
from `management`.`salary_management`;

-- comment on column cn_salary_management.工资编号 not supported: 薪资拥有者编号

-- comment on column cn_salary_management.员工姓名 not supported: 薪资拥有者

-- comment on column cn_salary_management.基础工资 not supported: 基础工资

-- comment on column cn_salary_management.绩效奖金 not supported: 薪资奖励

-- comment on column cn_salary_management.补贴 not supported: 补贴

