create definer = root@localhost view cn_training_management as
select `management`.`training_management`.`tra_id`         AS `培训编号`,
       `management`.`training_management`.`tra_instructor` AS `培训师`,
       `management`.`training_management`.`tra_trainer`    AS `培训人员`,
       `management`.`training_management`.`tra_period`     AS `培训期数`,
       `management`.`training_management`.`tra_result`     AS `培训结果`
from `management`.`training_management`;

-- comment on column cn_training_management.培训编号 not supported: 培训编号

-- comment on column cn_training_management.培训师 not supported: 培训讲师

-- comment on column cn_training_management.培训人员 not supported: 被培训者

-- comment on column cn_training_management.培训期数 not supported: 培训时间

-- comment on column cn_training_management.培训结果 not supported: 培训效果

