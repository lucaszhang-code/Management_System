create definer = root@localhost view cn_assessment_management as
select `management`.`assessment_management`.`ass_id`       AS `被评估者编号`,
       `management`.`assessment_management`.`ass_name`     AS `被评估者名称`,
       `management`.`assessment_management`.`ass_behavior` AS `评价`
from `management`.`assessment_management`;

-- comment on column cn_assessment_management.被评估者编号 not supported: 被评估者编号

-- comment on column cn_assessment_management.被评估者名称 not supported: 被评估者

-- comment on column cn_assessment_management.评价 not supported: 评价

