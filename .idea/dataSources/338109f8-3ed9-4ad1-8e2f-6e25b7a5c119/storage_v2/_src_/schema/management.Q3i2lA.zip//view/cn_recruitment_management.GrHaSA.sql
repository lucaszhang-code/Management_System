create definer = root@localhost view cn_recruitment_management as
select `management`.`recruitment_management`.`recru_id`       AS `招聘编号`,
       `management`.`recruitment_management`.`recru_empolyer` AS `面试官`,
       `management`.`recruitment_management`.`recru_empolyee` AS `面试人员`,
       `management`.`recruitment_management`.`recru_loaction` AS `招聘地点`,
       `management`.`recruitment_management`.`recru_date`     AS `招聘日期`,
       `management`.`recruitment_management`.`recru_record`   AS `招聘记录`,
       `management`.`recruitment_management`.`recru_result`   AS `招聘结果`
from `management`.`recruitment_management`;

-- comment on column cn_recruitment_management.招聘编号 not supported: 招聘信息编号

-- comment on column cn_recruitment_management.面试官 not supported: 面试官

-- comment on column cn_recruitment_management.面试人员 not supported: 面试人员

-- comment on column cn_recruitment_management.招聘地点 not supported: 面试地点

-- comment on column cn_recruitment_management.招聘日期 not supported: 面试时间

-- comment on column cn_recruitment_management.招聘记录 not supported: 面试记录

-- comment on column cn_recruitment_management.招聘结果 not supported: 是否录用

