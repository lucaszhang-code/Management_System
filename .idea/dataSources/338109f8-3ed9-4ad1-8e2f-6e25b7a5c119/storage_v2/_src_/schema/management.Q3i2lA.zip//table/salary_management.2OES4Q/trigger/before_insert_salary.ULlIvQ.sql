create definer = root@localhost trigger before_insert_salary
    before insert
    on salary_management
    for each row
    SET NEW.sal_sum = NEW.sal_base + NEW.sal_reward + NEW.sal_subsidy;

