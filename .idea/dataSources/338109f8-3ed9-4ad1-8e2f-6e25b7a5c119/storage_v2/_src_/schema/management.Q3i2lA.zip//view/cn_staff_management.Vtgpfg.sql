create definer = root@localhost view cn_staff_management as
select `management`.`staff_management`.`sta_id`           AS `员工编号`,
       `management`.`staff_management`.`sta_name`         AS `员工姓名`,
       `management`.`staff_management`.`sta_gender`       AS `员工性别`,
       `management`.`staff_management`.`sta_birth`        AS `员工生日`,
       `management`.`staff_management`.`sta_contact_info` AS `员工联系方式`,
       `management`.`staff_management`.`sta_department`   AS `员工部门`,
       `management`.`staff_management`.`sta_job`          AS `员工职位`
from `management`.`staff_management`;

